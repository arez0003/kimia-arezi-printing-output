//Task 1*************************
//variables
let a = 3;
let b = 5;
let c

//Output
let output = 'let a = 3;\nlet b = 5;\nlet c'

output = output +'\n---------'+ '\n'+'\na+b ='+(a+b)+'\na-b ='+(a-b)+'\na*b ='+(a*b)+'\na/b ='+(a/b)+'\na%b ='+(a%b)+'\na+=b ='+(a+=b)+'\na-=b ='+(a-=b)+'\na*=b ='+(a*=b)+'\na/=b ='+(a/=b)+'\na%=b ='+(a%=b)+'\na==b: '+(a==b)+'\na!=b: '+(a!=b)+'\na>b: '+(a>b)+'\na<b: '+(a<b)+'\n!a&&!c: '+(!a&&!c)+'\n!a||!c: '+ (!a||!c);

alert(output);


//Task 2*************************
//Frist Name
let first_name = 'Kimia';

//Last Name
let last_name = 'Arezi';

//E-mail
let email = 'arez0003@algonquinlive.com';

// Output
//let output = 'let first_name='Kimia';let last_name = 'Arezi';let email = 'arez0003@algonquinlive.com''   


output = "My name is" + " " +first_name + " " + last_name + "." + " " + "You can contact me at " + email
alert(output);
